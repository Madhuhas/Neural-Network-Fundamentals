#!/usr/bin/env python3
"""
CS5720 Assignment 1: Neural Network Fundamentals
Starter Code - Build a Neural Network from Scratch

Instructions:
- Complete all TODO sections
- Use only NumPy for computations
- Follow the docstring specifications carefully
- Run test_solution.py to verify your implementation
"""

import numpy as np
import struct
import gzip
from typing import List, Tuple, Dict
import pickle


# ============================================================================
# Data Loading Utilities
# ============================================================================

def load_mnist(path='data/'):
    """
    Load MNIST dataset from files or download if not present.
    
    Returns:
        X_train, y_train, X_test, y_test as numpy arrays
    """
    import os
    import urllib.request
    
    # Create data directory if it doesn't exist
    if not os.path.exists(path):
        os.makedirs(path)
    
    # MNIST file information
    files = {
        'train_images': 'train-images-idx3-ubyte.gz',
        'train_labels': 'train-labels-idx1-ubyte.gz',
        'test_images': 't10k-images-idx3-ubyte.gz',
        'test_labels': 't10k-labels-idx1-ubyte.gz'
    }
    
    # Download files if not present
    base_url = 'https://github.com/fgnt/mnist'
    for file in files.values():
        filepath = os.path.join(path, file)
        if not os.path.exists(filepath):
            print(f"Downloading {file}...")
            urllib.request.urlretrieve(base_url + file, filepath)
    
    # Load data
    def load_images(filename):
        with gzip.open(filename, 'rb') as f:
            magic, num, rows, cols = struct.unpack('>IIII', f.read(16))
            images = np.frombuffer(f.read(), dtype=np.uint8)
            images = images.reshape(num, rows * cols)
            return images / 255.0  # Normalize to [0, 1]
    
    def load_labels(filename):
        with gzip.open(filename, 'rb') as f:
            magic, num = struct.unpack('>II', f.read(8))
            labels = np.frombuffer(f.read(), dtype=np.uint8)
            return labels
    
    X_train = load_images(os.path.join(path, files['train_images']))
    y_train = load_labels(os.path.join(path, files['train_labels']))
    X_test = load_images(os.path.join(path, files['test_images']))
    y_test = load_labels(os.path.join(path, files['test_labels']))
    
    return X_train, y_train, X_test, y_test


def one_hot_encode(y, num_classes=10):
    """Convert integer labels to one-hot encoding."""
    one_hot = np.zeros((y.shape[0], num_classes))
    one_hot[np.arange(y.shape[0]), y] = 1
    return one_hot


# ============================================================================
# Layer Implementations
# ============================================================================

class Layer:
    """Base class for all layers."""
    def forward(self, X):
        raise NotImplementedError
    
    def backward(self, dL_dY):
        raise NotImplementedError
    
    def get_params(self):
        return {}
    
    def get_grads(self):
        return {}
    
    def set_params(self, params):
        pass


class Dense(Layer):
    """
    Fully connected (dense) layer.
    
    Parameters:
        input_dim: Number of input features
        output_dim: Number of output features
        weight_init: Weight initialization method ('xavier', 'he', 'normal')
    """
    def __init__(self, input_dim, output_dim, weight_init='xavier'):
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # TODO: Initialize weights and biases
        # Hint: Use different initialization strategies:
        # - 'xavier': sqrt(2 / (input_dim + output_dim))
        # - 'he': sqrt(2 / input_dim)
        # - 'normal': standard normal * 0.01
        self.W = None  # Shape: (input_dim, output_dim)
        self.b = None  # Shape: (output_dim,)
        
        # Storage for backward pass
        self.X = None
        self.dW = None
        self.db = None
    
    def forward(self, X):
        """
        Forward pass: Y = XW + b
        
        Args:
            X: Input data, shape (batch_size, input_dim)
            
        Returns:
            Y: Output data, shape (batch_size, output_dim)
        """
        # TODO: Implement forward pass
        # Store X for backward pass
        pass
    
    def backward(self, dL_dY):
        """
        Backward pass: compute gradients.
        
        Args:
            dL_dY: Gradient of loss w.r.t. output, shape (batch_size, output_dim)
            
        Returns:
            dL_dX: Gradient of loss w.r.t. input, shape (batch_size, input_dim)
        """
        # TODO: Compute gradients
        # dL_dW = X.T @ dL_dY
        # dL_db = sum(dL_dY, axis=0)
        # dL_dX = dL_dY @ W.T
        pass
    
    def get_params(self):
        return {'W': self.W, 'b': self.b}
    
    def get_grads(self):
        return {'W': self.dW, 'b': self.db}
    
    def set_params(self, params):
        self.W = params['W']
        self.b = params['b']


# ============================================================================
# Activation Functions
# ============================================================================

class Activation(Layer):
    """Base class for activation functions."""
    def __init__(self):
        self.cache = None


class ReLU(Activation):
    """Rectified Linear Unit activation function."""
    
    def forward(self, X):
        """
        Forward pass: f(x) = max(0, x)
        
        Args:
            X: Input data
            
        Returns:
            Output after applying ReLU
        """
        # TODO: Implement ReLU forward pass
        # Store input for backward pass
        pass
    
    def backward(self, dL_dY):
        """
        Backward pass: f'(x) = 1 if x > 0 else 0
        
        Args:
            dL_dY: Gradient of loss w.r.t. output
            
        Returns:
            dL_dX: Gradient of loss w.r.t. input
        """
        # TODO: Implement ReLU backward pass
        pass


class Sigmoid(Activation):
    """Sigmoid activation function."""
    
    def forward(self, X):
        """
        Forward pass: f(x) = 1 / (1 + exp(-x))
        
        Args:
            X: Input data
            
        Returns:
            Output after applying sigmoid
        """
        # TODO: Implement sigmoid forward pass
        # Store output for backward pass
        pass
    
    def backward(self, dL_dY):
        """
        Backward pass: f'(x) = f(x) * (1 - f(x))
        
        Args:
            dL_dY: Gradient of loss w.r.t. output
            
        Returns:
            dL_dX: Gradient of loss w.r.t. input
        """
        # TODO: Implement sigmoid backward pass
        pass


class Softmax(Activation):
    """Softmax activation function."""
    
    def forward(self, X):
        """
        Forward pass: f(x_i) = exp(x_i) / sum(exp(x))
        
        Args:
            X: Input data, shape (batch_size, num_classes)
            
        Returns:
            Output probabilities, shape (batch_size, num_classes)
        """
        # TODO: Implement softmax forward pass
        # Hint: Subtract max for numerical stability
        pass
    
    def backward(self, dL_dY):
        """
        Backward pass for softmax.
        
        Args:
            dL_dY: Gradient of loss w.r.t. output
            
        Returns:
            dL_dX: Gradient of loss w.r.t. input
        """
        # TODO: Implement softmax backward pass
        # This is complex - consider the Jacobian matrix
        pass


# ============================================================================
# Loss Functions
# ============================================================================

class Loss:
    """Base class for loss functions."""
    def compute(self, y_pred, y_true):
        raise NotImplementedError
    
    def gradient(self, y_pred, y_true):
        raise NotImplementedError


class MSELoss(Loss):
    """Mean Squared Error loss."""
    
    def compute(self, y_pred, y_true):
        """
        Compute MSE loss: L = 0.5 * mean((y_pred - y_true)^2)
        
        Args:
            y_pred: Predictions, shape (batch_size, num_features)
            y_true: True values, shape (batch_size, num_features)
            
        Returns:
            Scalar loss value
        """
        # TODO: Implement MSE loss
        pass
    
    def gradient(self, y_pred, y_true):
        """
        Compute gradient of MSE loss.
        
        Args:
            y_pred: Predictions
            y_true: True values
            
        Returns:
            Gradient w.r.t. predictions
        """
        # TODO: Implement MSE gradient
        # dL/dy_pred = (y_pred - y_true) / batch_size
        pass


class CrossEntropyLoss(Loss):
    """Cross-entropy loss for classification."""
    
    def compute(self, y_pred, y_true):
        """
        Compute cross-entropy loss: L = -mean(sum(y_true * log(y_pred)))
        
        Args:
            y_pred: Predicted probabilities, shape (batch_size, num_classes)
            y_true: True labels (one-hot), shape (batch_size, num_classes)
            
        Returns:
            Scalar loss value
        """
        # TODO: Implement cross-entropy loss
        # Add small epsilon to prevent log(0)
        pass
    
    def gradient(self, y_pred, y_true):
        """
        Compute gradient of cross-entropy loss.
        
        Args:
            y_pred: Predicted probabilities
            y_true: True labels (one-hot)
            
        Returns:
            Gradient w.r.t. predictions
        """
        # TODO: Implement cross-entropy gradient
        # For softmax + cross-entropy: gradient = (y_pred - y_true) / batch_size
        pass


# ============================================================================
# Optimizers
# ============================================================================

class Optimizer:
    """Base class for optimizers."""
    def update(self, params, grads):
        raise NotImplementedError


class SGD(Optimizer):
    """Stochastic Gradient Descent optimizer."""
    
    def __init__(self, learning_rate=0.01):
        self.lr = learning_rate
    
    def update(self, params, grads):
        """
        Update parameters using vanilla SGD.
        
        Args:
            params: Dictionary of parameters
            grads: Dictionary of gradients
        """
        # TODO: Implement SGD update rule
        # params = params - learning_rate * grads
        pass


class Momentum(Optimizer):
    """SGD with momentum optimizer."""
    
    def __init__(self, learning_rate=0.01, momentum=0.9):
        self.lr = learning_rate
        self.momentum = momentum
        self.velocity = {}
    
    def update(self, params, grads):
        """
        Update parameters using SGD with momentum.
        
        Args:
            params: Dictionary of parameters
            grads: Dictionary of gradients
        """
        # TODO: Implement momentum update rule
        # v = momentum * v - learning_rate * grads
        # params = params + v
        pass


# ============================================================================
# Neural Network Class
# ============================================================================

class NeuralNetwork:
    """
    Modular neural network implementation.
    
    Example usage:
        model = NeuralNetwork()
        model.add(Dense(784, 128))
        model.add(ReLU())
        model.add(Dense(128, 10))
        model.add(Softmax())
        model.compile(loss=CrossEntropyLoss(), optimizer=SGD(0.01))
        model.fit(X_train, y_train, epochs=10, batch_size=32)
    """
    
    def __init__(self):
        self.layers = []
        self.loss_fn = None
        self.optimizer = None
    
    def add(self, layer):
        """Add a layer to the network."""
        self.layers.append(layer)
    
    def compile(self, loss, optimizer):
        """Configure the model for training."""
        self.loss_fn = loss
        self.optimizer = optimizer
    
    def forward(self, X):
        """
        Forward propagation through all layers.
        
        Args:
            X: Input data
            
        Returns:
            Output of the network
        """
        # TODO: Implement forward pass through all layers
        pass
    
    def backward(self, dL_dY):
        """
        Backward propagation through all layers.
        
        Args:
            dL_dY: Gradient of loss w.r.t. network output
        """
        # TODO: Implement backward pass through all layers in reverse order
        pass
    
    def update_params(self):
        """Update parameters of all trainable layers using the optimizer."""
        # TODO: Collect parameters and gradients from all layers
        # Use optimizer to update parameters
        pass
    
    def fit(self, X_train, y_train, epochs, batch_size, 
            X_val=None, y_val=None, verbose=True):
        """
        Train the neural network.
        
        Args:
            X_train: Training data
            y_train: Training labels
            epochs: Number of training epochs
            batch_size: Batch size for mini-batch training
            X_val: Validation data (optional)
            y_val: Validation labels (optional)
            verbose: Print training progress
            
        Returns:
            Dictionary containing training history
        """
        history = {'train_loss': [], 'train_acc': [], 
                   'val_loss': [], 'val_acc': []}
        
        n_samples = X_train.shape[0]
        n_batches = n_samples // batch_size
        
        for epoch in range(epochs):
            # TODO: Implement training loop
            # 1. Shuffle training data
            # 2. Process mini-batches
            # 3. Forward pass
            # 4. Compute loss
            # 5. Backward pass
            # 6. Update parameters
            # 7. Track metrics
            
            if verbose:
                print(f"Epoch {epoch+1}/{epochs}")
                # Print metrics
            
        return history
    
    def predict(self, X):
        """
        Make predictions on input data.
        
        Args:
            X: Input data
            
        Returns:
            Predictions (class indices for classification)
        """
        # TODO: Forward pass and return predictions
        pass
    
    def evaluate(self, X, y):
        """
        Evaluate model performance.
        
        Args:
            X: Input data
            y: True labels
            
        Returns:
            loss, accuracy
        """
        # TODO: Compute loss and accuracy
        pass
    
    def save_weights(self, filename):
        """Save model weights to file."""
        weights = {}
        for i, layer in enumerate(self.layers):
            if hasattr(layer, 'get_params'):
                weights[f'layer_{i}'] = layer.get_params()
        np.savez(filename, **weights)
    
    def load_weights(self, filename):
        """Load model weights from file."""
        weights = np.load(filename)
        for i, layer in enumerate(self.layers):
            if hasattr(layer, 'set_params') and f'layer_{i}' in weights:
                layer.set_params(weights[f'layer_{i}'])


# ============================================================================
# Gradient Checking
# ============================================================================

def gradient_check(model, X, y, epsilon=1e-7):
    """
    Verify gradients using finite differences.
    
    Args:
        model: Neural network model
        X: Sample input data
        y: Sample labels
        epsilon: Small value for numerical differentiation
        
    Returns:
        Dictionary with gradient checking results
    """
    # TODO: Implement gradient checking
    # 1. Compute gradients using backpropagation
    # 2. Compute numerical gradients using finite differences
    # 3. Compare and return relative error
    pass


# ============================================================================
# Main Training Script
# ============================================================================

if __name__ == "__main__":
    # Load MNIST dataset
    print("Loading MNIST dataset...")
    X_train, y_train, X_test, y_test = load_mnist()
    
    # Convert labels to one-hot encoding
    y_train_oh = one_hot_encode(y_train)
    y_test_oh = one_hot_encode(y_test)
    
    # Create model
    print("Building neural network...")
    model = NeuralNetwork()
    
    # TODO: Build the network architecture
    # Input (784) → Dense (128) → ReLU → Dense (64) → ReLU → Dense (10) → Softmax
    
    # TODO: Compile model with CrossEntropyLoss and SGD optimizer
    
    # TODO: Train the model
    print("Training model...")
    # history = model.fit(...)
    
    # TODO: Evaluate on test set
    print("Evaluating model...")
    # test_loss, test_acc = model.evaluate(X_test, y_test_oh)
    
    # TODO: Save model weights
    # model.save_weights('model_weights.npz')
    
    # TODO: Save training log
    # with open('training_log.txt', 'w') as f:
    #     f.write("Training Log\n")
    #     ...
    
    # TODO: Save sample predictions
    # predictions = model.predict(X_test[:100])
    # np.savetxt('predictions_sample.txt', predictions, fmt='%d')
    
    print("Training complete!")